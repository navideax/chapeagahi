<?php
//
// Create a sub-tab
CSF::createSection( $prefix, array(
    'parent' => 'main_setting', // The slug id of the parent section
    'title'  => 'هویت سایت',
    'fields' => array(


        array(
            'id'      => 'fix-logo',
            'type'    => 'media',
            'title' => 'انتخاب لوگو ثابت',
            'library' => 'image',
            'button_title' => 'انتخاب (ترجیحا در سایز 55×312)',
            'url' => false,
            'preview_size' => 'full',
            'subtitle' => 'این لوگو در هنگام ثابت بودن هدر نمایش داده خواهد شد!',
        ),
        array(
            'id'      => 'scroll-logo',
            'type'    => 'media',
            'title' => 'انتخاب لوگو اسکرول',
            'library' => 'image',
            'button_title' => 'انتخاب (ترجیحا در سایز 55×312)',
            'url' => false,
            'preview_size' => 'full',
            'subtitle' => 'این لوگو در هنگام اسکرول شدن نمایش داده خواهد شد!',
        ),

        array(
            'id'         => 'slide-cat',
            'type'       => 'checkbox',
            'title'      => 'انتخاب دسته پست های زیر هدر',
            'options'    => 'categories',
            'query_args' => array(
                'orderby'  => 'post_title',
                'order'    => 'ASC',
            ),
        ),

    )
) );


CSF::createSection( $prefix, array(
    'parent' => 'main_setting', // The slug id of the parent section
    'title'  => 'رنگبندی سایت',
    'fields' => array(


        array(
            'id'         => 'dark-light',
            'type'       => 'radio',
            'title'      => 'دارک / لایت',
            'options'    => array(
                'dl-user' => 'به انتخاب کاربر',
                'dl-private' => 'اختصاصی',
            ),
            'default'    => 'dl-user'
        ),

        array(
            'id'         => 'user-dark-light',
            'type'       => 'radio',
            'title'      => 'انتخاب پیش فرض',
            'subtitle'      => 'سایت در حالت پیش فرض بر روی کدام مود قرار بگیرد؟',
            'options'    => array(
                'dark' => 'دارک',
                'light' => 'لایت',
            ),
            'default'    => 'light',
            'dependency' => array( 'dark-light', '==', 'dl-user' )
        ),


        array(
            'id'         => 'private-dark-light',
            'type'       => 'radio',
            'title'      => 'انتخاب مود ثابت',
            'subtitle'      => 'سایت بر روی کدام مود قرار بگیرد؟',
            'options'    => array(
                'private-dark' => 'دارک',
                'private-light' => 'لایت',
            ),
            'default'    => 'private-light',
            'dependency' => array( 'dark-light', '==', 'dl-private' )
        ),

        array(
            'id'      => 'ta-color',
            'type'    => 'color',
            'title'   => 'رنگ تاثیرگذار سایت',
            'default' => '#e4002b'
        ),

    )
) );