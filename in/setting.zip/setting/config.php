<?php
require get_template_directory() .'/in/csf/codestar-framework.php';


// Control core classes for avoid errors
if( class_exists( 'CSF' ) ) {

    //
    // Set a unique slug-like ID
    $prefix = 'setting_magit';
    // Create options
    CSF::createOptions($prefix, array(
        'menu_title' => 'تنظیمات پوسته',
        'menu_slug' => 'setting_magit',
        'framework_title' => 'تنظیمات مگیت <small style="font-weight: 800"><b>کدیاتو</b></small>',
        'menu_position' => 60,
    ));


    //
    // Create a top-tab
    CSF::createSection( $prefix, array(
        'id'    => 'main_setting', // Set a unique slug-like ID
        'title' => 'تنظیمات عمومی',
    ) );
    require get_template_directory() .'/in/setting/s-main.php';



    //
    // Create a top-tab
    CSF::createSection( $prefix, array(
        'id'    => 'box_setting', // Set a unique slug-like ID
        'title' => 'تنظیمات باکس مطالب',
    ) );
    require get_template_directory() .'/in/setting/s-box.php';

    CSF::createSection( $prefix, array(
        'id'    => 'sidebar_index_setting', // Set a unique slug-like ID
        'title' => 'تنظیمات سایدبار صفحه اصلی',
    ) );
    require get_template_directory() .'/in/setting/s-sidebar-index.php';


    CSF::createSection( $prefix, array(
        'id'    => 'single_setting', // Set a unique slug-like ID
        'title' => 'تنظیمات صفحه مطالب',
    ) );
    require get_template_directory() .'/in/setting/s-single.php';

    CSF::createSection( $prefix, array(
        'id'    => 'cat_setting', // Set a unique slug-like ID
        'title' => 'تنظیمات صفحه دسته بندی',
    ) );
    require get_template_directory() .'/in/setting/s-category.php';

    CSF::createSection( $prefix, array(
        'id'    => 'footer_setting', // Set a unique slug-like ID
        'title' => 'تنظیمات فوتر',
    ) );
    require get_template_directory() .'/in/setting/s-footer.php';


    CSF::createSection( $prefix, array(
        'id'    => 'pri_setting', // Set a unique slug-like ID
        'title' => 'تنظیمات اختصاصی',
    ) );
    require get_template_directory() .'/in/setting/pri-setting.php';


}






// Control core classes for avoid errors
if( class_exists( 'CSF' ) ) {

    //
    // Set a unique slug-like ID
    $prefix = 'menu_setting_magit';

    //
    // Create profile options
    CSF::createNavMenuOptions( $prefix, array(
        'data_type' => 'serialize', // The type of the database save options. `serialize` or `unserialize`
    ) );

    //
    // Create a section
    CSF::createSection( $prefix, array(
        'fields' => array(

            array(
                'id'    => 'menu_item_icon',
                'type'  => 'text',
                'title' => 'کد آیکون',
                'subtitle' => 'از سایت  <a href="https://fontawesome.com/search">fontawsome</a>',
            ),

        )
    ) );

}



if( ! class_exists( 'YOUR_Walker_Nav_Menu' ) ) {
    class YOUR_Walker_Nav_Menu extends Walker_Nav_Menu{

        public function start_el( &$output, $item, $depth = 0, $args = array(), $id = 0 ) {

            // ------------------------------------------------------------------------------
            // "data_type => serialize" usage.
            $meta = get_post_meta( $item->ID, 'menu_setting_magit', true );
            // alternative: $meta = $item->_prefix_menu_options;

            if( ! empty( $meta['menu_item_icon'] ) ) {
                $item->title = $meta['menu_item_icon'] . $item->title;
            }
            // ------------------------------------------------------------------------------

            parent::start_el( $output, $item, $depth, $args, $id );

        }

    }
}






// Control core classes for avoid errors
if( class_exists( 'CSF' ) ) {

    //
    // Set a unique slug-like ID
    $prefix = 'magit_post_options';

    //
    // Create a metabox
    CSF::createMetabox( $prefix, array(
        'title'     => 'تنظیمات مطالب',
        'post_type' => 'post',
        'context'   => 'side', // The context within the screen where the boxes should display. `normal`, `side`, `advanced`
    ) );

    //
    // Create a section
    CSF::createSection( $prefix, array(
        'title'  => 'پست ویژه',
        'fields' => array(

            array(
                'id'      => 'vip-post',
                'type'    => 'checkbox',
                'title'   => '',
                'label'   => 'بصورت بزرگ نمایش داده خواهد شد',
                'default' => false // or false
            ),
        )
    ) );

}



// Control core classes for avoid errors
if( class_exists( 'CSF' ) ) {

    //
    // Set a unique slug-like ID
    $prefix = 'magit_cat_taxonomy_options';

    //
    // Create taxonomy options
    CSF::createTaxonomyOptions( $prefix, array(
        'taxonomy'  => 'category',
        'data_type' => 'serialize', // The type of the database save options. `serialize` or `unserialize`
    ) );

    //
    // Create a section
    CSF::createSection( $prefix, array(
        'fields' => array(
            array(
                'id'    => 'sec-cat-title',
                'type'  => 'text',
                'title' => 'نام نمایشی دسته',
                'subtitle' => 'جهت افزایش سئو وبسایت خود یک تیتر کامل مرتبط با دسته بندی جهت نمایش در سایت بنویسید(توضیحات مختصری هم در رابطه با دسته بندی در بخش «توضیح» بنویسید)',
            ),
        )
    ) );

}
